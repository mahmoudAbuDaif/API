const os = require('os');

// Print os.networkInterfaces() value
var net_int = os.networkInterfaces();

var no_of_network_interfaces = 0;
var list = {};
for (var key in net_int) {
    
    
    var net_infos = net_int[key];
    list[key] = net_infos
    
    
    // console.log(net_infos)
    // net_infos.forEach(element => {
    //     no_of_network_interfaces++;
    //     //console.log("\tinterface:");
    //     list = list + "\tinterface:\n";
    //     for (var attr in element) {
    //         // console.log("\t\t" + attr +
    //         // " : " + element[attr]);
    //         list = list + "\t\t" + attr +
    //             " : " + element[attr] + '\n';
    //     }
    // });
}










// console.log("total number of Network " +
//     "interfaces is " + no_of_network_interfaces);
// list = list + "total number of Network " +
//     "interfaces is " + no_of_network_interfaces;
//   const express = require('express'); // using express
// const socketIO = require('socket.io');
// const http = require('http') 
// const port = process.env.PORT||3000 // setting the port 
// let app = express();
// let server = http.createServer(app)
// let io = socketIO(server)

// io.on('connection', (socket)=>{
//     console.log('New user connected');
//   });
// server.listen(port);

module.exports = list